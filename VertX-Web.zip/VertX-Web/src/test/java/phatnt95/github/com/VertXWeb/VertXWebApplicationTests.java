package phatnt95.github.com.VertXWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VertXWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
