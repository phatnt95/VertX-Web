package phatnt95.github.com.VertXWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VertXWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(VertXWebApplication.class, args);
	}

}
